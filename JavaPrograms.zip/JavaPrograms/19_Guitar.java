public class Guitar implements Playable {
    public void play() {
        System.out.println("Playing the guitar");
    }
}
